import React from "react";

function RegisterPage() {
  return <div>RegisterPage</div>;
}

export default RegisterPage;
